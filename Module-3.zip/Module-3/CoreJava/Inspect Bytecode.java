public class BytecodeExample {
    public static void greet() {
        System.out.println("Hello Bytecode!");
    }
    public static void main(String[] args) {
        greet();
    }
}
